<?php 

include "koneksi.php";
session_start();

if(!isset($_SESSION['login'])){
    header("location:login.php?pesan=login");
}
$sql = "SELECT * FROM post order by no desc";
$query = mysqli_query($koneksi,$sql);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" 
    integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL"
        crossorigin="anonymous"></script>
    <title>Angram</title>
    <link rel="icon" type="image/x-icon" href="images/logo.png">
    <style>

      body {
        background-image: url(/insta/images/logo1.jpg);
      }
      .zoom {
        overflow: hidden;
      }
      .zoom img{
        transition: transform .2s;
        margin: 0 auto;
      }
      .zoom:hover img{
        transform: scale(1.3);
      }
    </style>
</head>
<body class="bg-dark backround">
<nav class="navbar navbar-expand-lg bg-dark" data-bs-theme="dark">
  <div class="container-fluid">
    <img src="images/logo.png" height="70" width="95">
    <a class="navbar-brand fw-bold" href="index.php">ANGRAM</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarColor01" aria-controls="navbarColor01" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarColor01">
      <ul class="navbar-nav me-auto">
      </ul>
      <form class="d-flex">
      <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#staticBackdrop"><i class="bi bi-window-plus"></i>
                        Upload
                    </button>
      <a href="logout.php" class="btn btn-danger"><i class="bi bi-box-arrow-left"></i> Quit</a>
      </form>
    </div>
  </div>
</nav>
<center>
    <div class="container">
  <div class="row mt-5">
    <?php while ($post = mysqli_fetch_assoc($query)) { ?>
      <div class="col-md-10 mb-4 mx-auto">
        <div class="card" style="width: 25rem;">
        <div class="zoom">
          <img src="images/<?= $post['foto'] ?>" alt="" width="100" class="card-img-top" alt="...">
          </div>
          <div class="card-body">
            <h5 class="card-title"><?= $post['lokasi'] ?></h5>
            <p class="card-text"><?= $post['caption'] ?></p>
            <a class = "btn btn-warning" data-bs-toggle="modal" data-bs-target="#editModal<?= $post['no'] ?>"><i class="bi bi-pencil-square"></i></a>
            <a href="hapus.php?no=<?= $post['no'] ?>" class = "btn btn-danger"><i class="bi bi-trash-fill"></i></a><br><br>
          </div>
        </div>
      </div>
  </div>
</div>
<!-- Modal -->
    <div class="modal fade" id="editModal<?= $post['no'] ?>" data-bs-backdrop="static" data-bs-keyboard="false"
          tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
          <div class="modal-dialog">
            <div class="modal-content" style="background-color:gray ;">
              <div class="modal-header">
                <h1 class="modal-title fs-5" id="exampleModalLabel">Form Edit Postingan</h1>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
              </div>
              <div class="container" align="left">
                <form action="proses_edit.php" method="post" enctype="multipart/form-data">
                  <input type="hidden" name="no" value="<?= $post['no'] ?>">
                  <input type="hidden" name="foto_lama" value="<?= $post['foto'] ?>" class="form-control">

                  <label for="">foto</label>
                  <input type="file" name="foto" id="" value="<?= $post['foto'] ?>" class="form-control"><br>
                  <img src="images/<?= $post['foto'] ?>" width="200" alt=""><br><br>
                  <label for="">Caption</label>
                  <input type="text" name="caption" id="" value="<?= $post['caption'] ?>" class="form-control"><br>
                  <label for="">Lokasi</label>
                  <input type="text" name="lokasi" id="" value="<?= $post['lokasi'] ?>" class="form-control"><br>
                  <div class="modal-footer">
                    <button type="submit" class="btn btn-primary" name="update">Update</button>
                    <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Close</button>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
      
      <?php } ?>
  </div>
<!-- Modal -->
  <div class="modal fade" id="staticBackdrop" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1"
        aria-labelledby="staticBackdropLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content" style="background-color:gray ;">
                <div class="modal-header">
                    <h1 class="modal-title fs-5" id="staticBackdropLabel">Form Tambah Postingan</h1>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <form action="proses_tambah.php" method="post" enctype="multipart/form-data">
                <div class="modal-body">
                        <div class="mb-3">
                            <label class="form-label">Foto</label>
                            <input type="file" name="foto" id="" required class="form-control">
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Caption</label>
                            <input type="text" name="caption" id="" class="form-control"><br>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Lokasi</label>
                            <input type="text" name="lokasi" id="" class="form-control"><br>
                        </div>                    
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary" name="simpan">Simpan</button>
                </div>
            </form>
            </div>
        </div>
    </div>
    </center>
</body>
</html>