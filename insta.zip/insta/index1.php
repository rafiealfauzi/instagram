<?php 
include "koneksi.php";
$sql = "SELECT * FROM post";
$query = mysqli_query($koneksi, $sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css" 
    integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.2/font/bootstrap-icons.css" 
    integrity="sha384-b6lVK+yci+bfDmaY1u0zE8YYJt0TZxLEAFyYSLHId4xoVvsrQu3INevFKo+Xir8e" crossorigin="anonymous">
    
    <title>Document</title>
</head>

<body>
<nav class="navbar navbar-light bg-light justify-content-between">
  <a href="tambah.php" class="btn btn-success"><i class="bi bi-plus-square"></i></a>
  <form class="form-inline">
  <a href="tambah.php" class="btn btn-success"><i class="bi bi-plus-square"></i></a>
  <a href="login/logout.php"><button class="btn btn-outline-danger" ><i class="fa-solid fa-right-from-bracket fa-xl"> KELUAR</i></button></a>
    
  </form>
</nav>
<center>
<?php while ($post = mysqli_fetch_assoc($query)) {?>
<div class="card" style="width: 18rem;">
<img src="images/<?= $post['foto']?>" alt="" width="100%" height="300">
  <div class="card-body">
    <h5 class="card-title"><?= $post ['caption']?></h5>
    <p class="card-text"><?= $post ['lokasi']?></p>
    <a href="edit.php?no=<?= $post ['no']?>"class="btn btn-primary"><i class="bi bi-pencil-fill"></i></a>
    <a href="hapus.php?no=<?= $post ['no']?>"class="btn btn-danger"><i class="bi bi-trash-fill"></i></a>
  </div>
</div>
<?php } ?>
</center>
</body>
</html>





<a href="tambah.php" class="btn btn-success"><i class="bi bi-plus-square"></i></a>
  <a href="logout.php" class="btn btn-danger"><i class="bi bi-box-arrow-left"></i></a>

  <!DOCTYPE html>
  <html lang="en">
  <head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
  </head>
  <body>
    
  </body>
  </html>




  <form action="proses_login.php" method="post">
            <input type="text" placeholder="Username" name="username" required autocomplete="off">
            <input type="password" placeholder="Password" name="password" required>
            <button type="submit">Log In</button>
        </form>